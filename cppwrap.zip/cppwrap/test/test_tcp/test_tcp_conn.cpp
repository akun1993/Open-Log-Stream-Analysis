

#include <iostream>
#include "loop_wrap.h"
#include "node_sockaddr.h"
#include "timer_wrap.h"
#include  <vector>

void startClients(LoopWrap &loop)
{

}

int main(int argc, char** args)
{
    LoopWrap &loop = LoopWrap::defaultLoop();

    // TimerWrap wrap(&loop,[](){
    //     printf("on time ot\n");
    // });
    //wrap.Update(1000,1000);

    loop.runInThisLoop([](){
        printf("SocketAddress serverAddr(127.0.0.1, 10005, SocketAddr::Ipv4);\n");
    });
    //SocketAddress serverAddr("127.0.0.1", 10005, SocketAddr::Ipv4);

    loop.runAfter(5.0,[](){
        printf("run after 5.0\n");
    });

    loop.runEvery(0.5,[](){
        printf("run every 0.5 time is %ld\n",time(NULL));
    });    

    loop.runEvery(1.0,[](){
        printf("run every 1.0 time is %ld\n",time(NULL));
    });

    loop.runEvery(10.0,[](){
        printf("run every 10.0 time is %ld\n",time(NULL));
    });

    startClients(loop);

    loop.run();

    return 0;
}
