#ifndef SRC_CONNECT_WRAP_H_
#define SRC_CONNECT_WRAP_H_

#include "req_wrap-inl.h"

class ConnectWrap : public ReqWrap<uv_connect_t> {
 public:
  ConnectWrap();
};

#endif  // SRC_CONNECT_WRAP_H_
