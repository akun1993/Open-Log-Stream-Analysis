
// internal
#ifndef __THIS_THREAD_H__
#define __THIS_THREAD_H__

namespace ThisThread
{
extern __thread int t_cachedTid;
extern __thread const char* t_threadName;
void cacheTid();

inline int threadId() {
    if (__builtin_expect(t_cachedTid == 0, 0)) {
        cacheTid();
    }
    return t_cachedTid;
}

inline const char* threadName() {
    return t_threadName;
}
}

#endif
