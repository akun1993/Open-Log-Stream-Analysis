

#ifndef   UV_EVENT_LOOP_HPP
#define   UV_EVENT_LOOP_HPP

#include <uv.h>
#include <atomic>
#include <mutex>
#include <functional>
#include <memory>
#include "clock_queue_base.h"

typedef std::function<void()> Functor;

class LoopWrap final
{
public:
    LoopWrap();
    ~LoopWrap();

    static LoopWrap& defaultLoop();

    int run();
    int stop();
    bool isRunning(){
        return is_running_;
    }
    bool isInLoopThread();
    void runInThisLoop( Functor func);
    uv_loop_t* handle();

    static const char* getErrorMessage(int status);

    TimerId runAt(Timetick time, TimerCallback cb) ;
    TimerId runAfter(double delay, TimerCallback cb);
    TimerId runEvery(double interval, TimerCallback cb);
    void cancel(TimerId timerId) ;

private:
    static void asyncCallback(uv_async_t* handle);
    LoopWrap( bool use_def);

    void asyncInit();

    uv_loop_t* loop_;
    std::mutex mutex_;
    uv_async_t task_queues_async_;
    std::vector<Functor> callbacks_;

    ClockQueueBase realClock_;
    ClockQueueBase alarmClock_; 
    ClockQueueBase monotonicClock_;
    ClockQueueBase boottimeClock_;

    bool callingPendingFunctors_{false};
    pid_t threadId_{0};
    bool  is_running_{false};
    
};

using LoopWrapPtr = std::shared_ptr<LoopWrap>;

#endif

