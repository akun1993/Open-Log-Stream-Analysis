#ifndef SRC_STREAM_BASE_INL_H_
#define SRC_STREAM_BASE_INL_H_

#include "stream_base.h"

StreamReq::StreamReq(StreamBase* stream) : stream_(stream) {}

// void StreamReq::AttachToObject(v8::Local<v8::Object> req_wrap_obj) {
//   CHECK_EQ(req_wrap_obj->GetAlignedPointerFromInternalField(
//                StreamReq::kStreamReqField),
//            nullptr);
//   req_wrap_obj->SetAlignedPointerInInternalField(StreamReq::kStreamReqField,
//                                                  this);
// }

// StreamReq* StreamReq::FromObject(v8::Local<v8::Object> req_wrap_obj) {
//   return static_cast<StreamReq*>(
//       req_wrap_obj->GetAlignedPointerFromInternalField(
//           StreamReq::kStreamReqField));
// }

void StreamReq::Dispose() {
  // BaseObjectPtr<AsyncWrap> destroy_me{GetAsyncWrap()};
  // object()->SetAlignedPointerInInternalField(StreamReq::kStreamReqField,
  //                                            nullptr);
  // destroy_me->Detach();
}

// v8::Local<v8::Object> StreamReq::object() { return GetAsyncWrap()->object();
// }

ShutdownWrap::ShutdownWrap(StreamBase* stream) : StreamReq(stream) {}

WriteWrap::WriteWrap(StreamBase* stream) : StreamReq(stream) {}

void StreamListener::PassReadErrorToPreviousListener(ssize_t nread) {
  CHECK_NOT_NULL(previous_listener_);
  previous_listener_->OnStreamRead(nread, uv_buf_init(nullptr, 0));
}

void StreamResource::PushStreamListener(StreamListener* listener) {
  CHECK_NOT_NULL(listener);
  CHECK_NULL(listener->stream_);

  listener->previous_listener_ = listener_;
  listener->stream_ = this;

  listener_ = listener;
}

uv_buf_t StreamResource::EmitAlloc(size_t suggested_size) {
  // DebugSealHandleScope seal_handle_scope;
  return listener_->OnStreamAlloc(suggested_size);
}

void StreamResource::EmitRead(ssize_t nread, const uv_buf_t& buf) {
  // DebugSealHandleScope seal_handle_scope;
  if (nread > 0) bytes_read_ += static_cast<uint64_t>(nread);
  listener_->OnStreamRead(nread, buf);
}

void StreamResource::EmitAfterWrite(WriteWrap* w, int status) {
  // DebugSealHandleScope seal_handle_scope;
  listener_->OnStreamAfterWrite(w, status);
}

void StreamResource::EmitAfterShutdown(ShutdownWrap* w, int status) {
  // DebugSealHandleScope seal_handle_scope;
  listener_->OnStreamAfterShutdown(w, status);
}

void StreamResource::EmitWantsWrite(size_t suggested_size) {
  // DebugSealHandleScope seal_handle_scope;
  listener_->OnStreamWantsWrite(suggested_size);
}

StreamBase::StreamBase() { PushStreamListener(&default_listener_); }

template <typename OtherBase>
SimpleShutdownWrap<OtherBase>::SimpleShutdownWrap(StreamBase* stream): ShutdownWrap(stream), OtherBase() {}

template <typename OtherBase>
SimpleWriteWrap<OtherBase>::SimpleWriteWrap(StreamBase* stream) : WriteWrap(stream), OtherBase() {}

#endif  // SRC_STREAM_BASE_INL_H_
