// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

#include "handle_wrap.h"

#include "util-inl.h"

void HandleWrap::Ref() {
  if (IsAlive()) uv_ref(GetHandle());
}

void HandleWrap::Unref() {
  if (IsAlive()) uv_unref(GetHandle());
}

void HandleWrap::Close() {
  if (state_ != kInitialized) return;

  uv_close(handle_, OnClose);
  state_ = kClosing;

  // if (!close_callback.IsEmpty() && close_callback->IsFunction() &&
  //     !persistent().IsEmpty()) {
  //   object()
  //       ->Set(env()->context(), env()->handle_onclose_symbol(),
  //       close_callback) .Check();
  // }
}

HandleWrap::HandleWrap(uv_handle_t* handle)
    : state_(kInitialized), handle_(handle) {
  handle_->data = this;
}

void HandleWrap::OnClose(uv_handle_t* handle) {
  CHECK_NOT_NULL(handle->data);

  HandleWrap* wrap = static_cast<HandleWrap*>(handle->data);

  CHECK_EQ(wrap->state_, kClosing);

  wrap->state_ = kClosed;
  wrap->OnClose();
}
