
#include <stdlib.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <sys/types.h>

namespace ThisThread
{
__thread int t_cachedTid = 0;
__thread const char* t_threadName = "unknown";

pid_t gettid() {
    return static_cast<pid_t>(::syscall(SYS_gettid));
}

void cacheTid() {
    if (t_cachedTid == 0) {
        t_cachedTid = gettid();
    }
}
}
