#include "stream_base.h"  // NOLINT(build/include_inline)

#include <climits>  // INT_MAX

#include "stream_base-inl.h"
#include "stream_wrap.h"
#include "handle_wrap.h"
#include "util-inl.h"

int StreamBase::Shutdown() {
  ShutdownWrap* req_wrap = CreateShutdownWrap();
  // if (req_wrap != nullptr) req_wrap_ptr.reset(req_wrap->GetAsyncWrap());

  int err = DoShutdown(req_wrap);

  if (err != 0 && req_wrap != nullptr) {
    req_wrap->Dispose();
  }

  const char* msg = Error();
  if (msg != nullptr) {
    // if (req_wrap_obj
    //         ->Set(env->context(), env->error_string(),
    //               OneByteString(env->isolate(), msg))
    //         .IsNothing()) {
    //   return UV_EBUSY;
    // }
    ClearError();
  }
  return err;
}

StreamWriteResult StreamBase::Write(uv_buf_t* bufs, size_t count,
                                    uv_stream_t* send_handle,
                                    bool skip_try_write) {
  int err;

  size_t total_bytes = 0;
  for (size_t i = 0; i < count; ++i) total_bytes += bufs[i].len;
  bytes_written_ += total_bytes;

  if (send_handle == nullptr && !skip_try_write) {
    err = DoTryWrite(&bufs, &count);
    if (err != 0 || count == 0) {
      return StreamWriteResult{false, err, nullptr, total_bytes};
    }
  }

  WriteWrap* req_wrap = CreateWriteWrap();
  // BaseObjectPtr<AsyncWrap> req_wrap_ptr(req_wrap->GetAsyncWrap());

  err = DoWrite(req_wrap, bufs, count, send_handle);
  bool async = err == 0;

  if (!async) {
    req_wrap->Dispose();
    req_wrap = nullptr;
  }

  const char* msg = Error();
  if (msg != nullptr) {
    // if (req_wrap_obj
    //         ->Set(env->context(), env->error_string(),
    //               OneByteString(env->isolate(), msg))
    //         .IsNothing()) {
    //   return StreamWriteResult{false, UV_EBUSY, nullptr, 0, {}};
    // }
    ClearError();
  }

  return StreamWriteResult{async, err, req_wrap, total_bytes};
}

int StreamBase::UseUserBuffer(char* buff, int length) {
  uv_buf_t buf = uv_buf_init(buff, length);
  PushStreamListener(new CustomBufferListener(buf));
  return 0;
}


void StreamBase::SetWriteResult(const StreamWriteResult& res) {
  // env_->stream_base_state()[kBytesWritten] = res.bytes;
  // env_->stream_base_state()[kLastWriteWasAsync] = res.async;
}

int StreamBase::Writev(uv_buf_t* uvbufs, size_t count, bool all_buffers) {
  // size_t count;
  // if (all_buffers)
  //   count = chunks->Length();
  // else
  //   count = chunks->Length() >> 1;

  MaybeStackBuffer<uv_buf_t, 16> bufs(count);

  size_t storage_size = 0;
  size_t offset;

  if (!all_buffers) {
    // Determine storage size first
    // for (size_t i = 0; i < count; i++) {
    //   // Buffer chunk, no additional storage required

    //   // String chunk
    //   Local<String> string;
    //   if (!chunk->ToString(context).ToLocal(&string)) return -1;
    //   Local<Value> next_chunk;
    //   if (!chunks->Get(context, i * 2 + 1).ToLocal(&next_chunk)) return -1;

    //   size_t chunk_size;
    //   if ((encoding == UTF8 && string->Length() > 65535 &&
    //        !StringBytes::Size(isolate, string, encoding).To(&chunk_size)) ||
    //       !StringBytes::StorageSize(isolate, string, encoding)
    //            .To(&chunk_size)) {
    //     return -1;
    //   }
    //   storage_size += chunk_size;
    // }

    // if (storage_size > INT_MAX) return UV_ENOBUFS;
  } else {
    for (size_t i = 0; i < count; i++) {
      bufs[i].base = uvbufs[i].base;
      bufs[i].len = uvbufs[i].len;
    }
  }

  // std::unique_ptr<BackingStore> bs;
  // if (storage_size > 0) {
  //   NoArrayBufferZeroFillScope no_zero_fill_scope(env->isolate_data());
  //   bs = ArrayBuffer::NewBackingStore(isolate, storage_size);
  // }

  offset = 0;
  if (!all_buffers) {
    // for (size_t i = 0; i < count; i++) {
    //   Local<Value> chunk;
    //   if (!chunks->Get(context, i * 2).ToLocal(&chunk)) return -1;

    //   // Write buffer
    //   if (Buffer::HasInstance(chunk)) {
    //     bufs[i].base = Buffer::Data(chunk);
    //     bufs[i].len = Buffer::Length(chunk);
    //     continue;
    //   }

    //   // Write string
    //   CHECK_LE(offset, storage_size);
    //   char* str_storage =
    //       static_cast<char*>(bs ? bs->Data() : nullptr) + offset;
    //   size_t str_size = (bs ? bs->ByteLength() : 0) - offset;

    //   str_size =
    //       StringBytes::Write(isolate, str_storage, str_size, string,
    //       encoding);
    //   bufs[i].base = str_storage;
    //   bufs[i].len = str_size;
    //   offset += str_size;
    // }
  }

  StreamWriteResult res = Write(*bufs, count, nullptr);
  SetWriteResult(res);
  // if (res.wrap != nullptr && storage_size > 0)
  // res.wrap->SetBackingStore(std::move(bs));
  return res.err;
}

int StreamBase::WriteBuffer(char* data, int length, uv_stream_t* send_handle) {
  uv_buf_t buf;
  buf.base = data;
  buf.len = length;

  StreamWriteResult res = Write(&buf, 1, send_handle);
  SetWriteResult(res);

  return res.err;
}

int StreamBase::WriteString(std::string& data, HandleWrap* wrap) {
  // Local<Object> req_wrap_obj = args[0].As<Object>();
  // Local<String> string = args[1].As<String>();
  // Local<Object> send_handle_obj;
  // if (args[2]->IsObject()) send_handle_obj = args[2].As<Object>();

  // Compute the size of the storage that the string will be flattened into.
  // For UTF8 strings that are very long, go ahead and take the hit for
  // computing their actual size, rather than tripling the storage.
  size_t storage_size = data.length();

  if (storage_size > INT_MAX) return UV_ENOBUFS;

  // Try writing immediately if write size isn't too big
  char stack_storage[16384];  // 16kb
  size_t data_size;
  size_t synchronously_written = 0;
  uv_buf_t buf;

  bool try_write = storage_size <= sizeof(stack_storage) &&
                   (!IsIPCPipe() || wrap == nullptr);
  if (try_write) {
    data_size = data.length();

    buf = uv_buf_init(stack_storage, data_size);

    uv_buf_t* bufs = &buf;
    size_t count = 1;
    const int err = DoTryWrite(&bufs, &count);
    // Keep track of the bytes written here, because we're taking a shortcut
    // by using `DoTryWrite()` directly instead of using the utilities
    // provided by `Write()`.
    synchronously_written = count == 0 ? data_size : data_size - buf.len;
    bytes_written_ += synchronously_written;

    // Immediate failure or success
    if (err != 0 || count == 0) {
      SetWriteResult(StreamWriteResult{false, err, nullptr, data_size});
      return err;
    }

    // Partial write
    CHECK_EQ(count, 1);
  }

  // std::unique_ptr<BackingStore> bs;

  if (try_write) {
    // Copy partial data
    // NoArrayBufferZeroFillScope no_zero_fill_scope(env->isolate_data());
    // bs = ArrayBuffer::NewBackingStore(isolate, buf.len);
    // memcpy(static_cast<char*>(bs->Data()), buf.base, buf.len);
    data_size = buf.len;
  } else {
    // Write it
    // NoArrayBufferZeroFillScope no_zero_fill_scope(env->isolate_data());
    // bs = ArrayBuffer::NewBackingStore(isolate, storage_size);
    // data_size = StringBytes::Write(isolate, static_cast<char*>(bs->Data()),
    //                                storage_size, string, enc);
  }

  CHECK_LE(data_size, storage_size);

  buf = uv_buf_init(const_cast<char*>(data.c_str()), data_size);

  uv_stream_t* send_handle = nullptr;

  if (IsIPCPipe() && !wrap) {
    send_handle = reinterpret_cast<uv_stream_t*>(wrap->GetHandle());
    // Reference LibuvStreamWrap instance to prevent it from being garbage
    // collected before `AfterWrite` is called.
  }

  StreamWriteResult res = Write(&buf, 1, send_handle, try_write);
  res.bytes += synchronously_written;

  SetWriteResult(res);
  // if (res.wrap != nullptr) res.wrap->SetBackingStore(std::move(bs));
  return res.err;
}

bool StreamBase::IsIPCPipe() { return false; }

int StreamBase::GetFD() { return -1; }

uint64_t StreamBase::GetBytesRead() { return bytes_read_; }

uint64_t StreamBase::GetBytesWritten() { return bytes_written_; }

int StreamResource::DoTryWrite(uv_buf_t** bufs, size_t* count) {
  // No TryWrite by default
  return 0;
}

const char* StreamResource::Error() const { return nullptr; }

void StreamResource::ClearError() {
  // No-op
}

uv_buf_t EmitToStreamListener::OnStreamAlloc(size_t suggested_size) {
  CHECK_NOT_NULL(stream_);
  // Environment* env = static_cast<StreamBase*>(stream_)->stream_env();
  // return env->allocate_managed_buffer(suggested_size);
  char* data = new char[suggested_size];
  uv_buf_t buf = uv_buf_init(static_cast<char*>(data), suggested_size);

  return buf;  
}

void EmitToStreamListener::OnStreamRead(ssize_t nread, const uv_buf_t& buf_) {
  CHECK_NOT_NULL(stream_);
  StreamBase* stream = static_cast<StreamBase*>(stream_);
  // Environment* env = stream->stream_env();
  // Isolate* isolate = env->isolate();
  // HandleScope handle_scope(isolate);
  // Context::Scope context_scope(env->context());
  // std::unique_ptr<BackingStore> bs = env->release_managed_buffer(buf_);

  // if (nread <= 0) {
  //   if (nread < 0) stream->CallJSOnreadMethod(nread, Local<ArrayBuffer>());
  //   return;
  // }

  // CHECK_LE(static_cast<size_t>(nread), bs->ByteLength());
  // bs = BackingStore::Reallocate(isolate, std::move(bs), nread);

  // stream->CallJSOnreadMethod(nread, ArrayBuffer::New(isolate,
  // std::move(bs)));
}

uv_buf_t CustomBufferListener::OnStreamAlloc(size_t suggested_size) {
  return buffer_;
}

void CustomBufferListener::OnStreamRead(ssize_t nread, const uv_buf_t& buf) {
  CHECK_NOT_NULL(stream_);

  StreamBase* stream = static_cast<StreamBase*>(stream_);
  // Environment* env = stream->stream_env();
  // HandleScope handle_scope(env->isolate());
  // Context::Scope context_scope(env->context());

  // In the case that there's an error and buf is null, return immediately.
  // This can happen on unices when POLLHUP is received and UV_EOF is returned
  // or when getting an error while performing a UV_HANDLE_ZERO_READ on Windows.
  // if (buf.base == nullptr && nread < 0) {
  //   stream->CallJSOnreadMethod(nread, Local<ArrayBuffer>());
  //   return;
  // }

  // CHECK_EQ(buf.base, buffer_.base);

  // MaybeLocal<Value> ret = stream->CallJSOnreadMethod(
  //     nread, Local<ArrayBuffer>(), 0, StreamBase::SKIP_NREAD_CHECKS);
  // Local<Value> next_buf_v;
  // if (ret.ToLocal(&next_buf_v) && !next_buf_v->IsUndefined()) {
  //   buffer_.base = Buffer::Data(next_buf_v);
  //   buffer_.len = Buffer::Length(next_buf_v);
  // }
}

void ReportWritesToStreamListener::OnStreamAfterReqFinished(
    StreamReq* req_wrap, int status) {
  StreamBase* stream = static_cast<StreamBase*>(stream_);
  // Environment* env = stream->stream_env();
  // if (!env->can_call_into_js()) return;
  // AsyncWrap* async_wrap = req_wrap->GetAsyncWrap();
  // HandleScope handle_scope(env->isolate());
  // Context::Scope context_scope(env->context());
  // CHECK(!async_wrap->persistent().IsEmpty());
  // Local<Object> req_wrap_obj = async_wrap->object();

  // Local<Value> argv[] = {Integer::New(env->isolate(), status),
  //                        stream->GetObject(), Undefined(env->isolate())};

  // const char* msg = stream->Error();
  // if (msg != nullptr) {
  //   argv[2] = OneByteString(env->isolate(), msg);
  //   stream->ClearError();
  // }

  // if (req_wrap_obj->Has(env->context(), env->oncomplete_string()).FromJust())
  //   async_wrap->MakeCallback(env->oncomplete_string(), arraysize(argv),
  //   argv);
}

void ReportWritesToStreamListener::OnStreamAfterWrite(WriteWrap* req_wrap,
                                                        int status) {
  OnStreamAfterReqFinished(req_wrap, status);
}

void ReportWritesToStreamListener::OnStreamAfterShutdown(
    ShutdownWrap* req_wrap, int status) {
  OnStreamAfterReqFinished(req_wrap, status);
}

void ShutdownWrap::OnDone(int status) {
  stream()->EmitAfterShutdown(this, status);
  Dispose();
}

void WriteWrap::OnDone(int status) {
  stream()->EmitAfterWrite(this, status);
  Dispose();
}

StreamListener::~StreamListener() {
  if (stream_ != nullptr) stream_->RemoveStreamListener(this);
}

void StreamListener::OnStreamAfterShutdown(ShutdownWrap* w, int status) {
  CHECK_NOT_NULL(previous_listener_);
  previous_listener_->OnStreamAfterShutdown(w, status);
}

void StreamListener::OnStreamAfterWrite(WriteWrap* w, int status) {
  CHECK_NOT_NULL(previous_listener_);
  previous_listener_->OnStreamAfterWrite(w, status);
}

StreamResource::~StreamResource() {
  while (listener_ != nullptr) {
    StreamListener* listener = listener_;
    listener->OnStreamDestroy();
    // Remove the listener if it didn’t remove itself. This makes the logic
    // in `OnStreamDestroy()` implementations easier, because they
    // may call generic cleanup functions which can just remove the
    // listener unconditionally.
    if (listener == listener_) RemoveStreamListener(listener_);
  }
}

void StreamResource::RemoveStreamListener(StreamListener* listener) {
  CHECK_NOT_NULL(listener);

  StreamListener* previous;
  StreamListener* current;

  // Remove from the linked list.
  // No loop condition because we want a crash if listener is not found.
  for (current = listener_, previous = nullptr;;
       previous = current, current = current->previous_listener_) {
    CHECK_NOT_NULL(current);
    if (current == listener) {
      if (previous != nullptr)
        previous->previous_listener_ = current->previous_listener_;
      else
        listener_ = listener->previous_listener_;
      break;
    }
  }

  listener->stream_ = nullptr;
  listener->previous_listener_ = nullptr;
}

ShutdownWrap* StreamBase::CreateShutdownWrap() {
  auto* wrap = new ShutdownWrap(this);
  return wrap;
}

WriteWrap* StreamBase::CreateWriteWrap() {
  auto* wrap = new WriteWrap(this);
  return wrap;
}

void StreamReq::Done(int status, const char* error_str) {
  if (error_str != nullptr) {
    // v8::HandleScope handle_scope(env->isolate());
    // if (async_wrap->object()
    //         ->Set(env->context(), env->error_string(),
    //               OneByteString(env->isolate(), error_str))
    //         .IsNothing()) {
    //   return;
    // }
  }

  OnDone(status);
}
