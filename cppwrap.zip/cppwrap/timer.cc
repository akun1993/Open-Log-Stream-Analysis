

#include "timer.h"

std::atomic_int64_t Timer::s_numCreated_;

void Timer::restart(Timetick now) {
    if (repeat_) {
        expiration_ = addTime(now, interval_);
    } else {
        expiration_ = Timetick::invalid();
    }
}
