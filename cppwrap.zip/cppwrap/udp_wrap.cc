// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

#include "udp_wrap.h"

#include "handle_wrap.h"
#include "req_wrap-inl.h"
#include "util-inl.h"

namespace {
template <int (*fn)(uv_udp_t*, int)>
int SetLibuvInt32(UDPWrap* wrap, int flag) {
   int err = fn(wrap->GetLibuvHandle(), flag);
   return err;
}
}  // namespace

class SendWrap : public ReqWrap<uv_udp_send_t> {
 public:
  SendWrap(bool have_callback);
  inline bool have_callback() const;
  size_t msg_size;

 private:
  const bool have_callback_;
};

SendWrap::SendWrap(bool have_callback)
    : ReqWrap(), have_callback_(have_callback) {}

bool SendWrap::have_callback() const { return have_callback_; }

UDPListener::~UDPListener() {
  if (wrap_ != nullptr) wrap_->set_listener(nullptr);
}

UDPWrapBase::~UDPWrapBase() { set_listener(nullptr); }

UDPListener* UDPWrapBase::listener() const {
  CHECK_NOT_NULL(listener_);
  return listener_;
}

void UDPWrapBase::set_listener(UDPListener* listener) {
  if (listener_ != nullptr) listener_->wrap_ = nullptr;
  listener_ = listener;
  if (listener_ != nullptr) {
    CHECK_NULL(listener_->wrap_);
    listener_->wrap_ = this;
  }
}

UDPWrap::UDPWrap(uv_loop_t* loop)
    : HandleWrap(reinterpret_cast<uv_handle_t*>(&handle_)) {
  int r = uv_udp_init(loop, &handle_);
  CHECK_EQ(r, 0);  // can't fail anyway

  set_listener(this);
}

int UDPWrap::GetFD() {
  int fd = UV_EBADF;
#if !defined(_WIN32)
  uv_fileno(reinterpret_cast<uv_handle_t*>(&handle_), &fd);
#endif
  return fd;
}

int sockaddr_for_family(int address_family, const char* address,
                        const unsigned short port,
                        struct sockaddr_storage* addr) {
  switch (address_family) {
    case AF_INET:
      return uv_ip4_addr(address, port, reinterpret_cast<sockaddr_in*>(addr));
    case AF_INET6:
      return uv_ip6_addr(address, port, reinterpret_cast<sockaddr_in6*>(addr));
    default:
      UNREACHABLE("unexpected address family");
  }
}

int UDPWrap::DoBind(const std::string& address, uint16_t port, uint32_t flags,
                    int family) {
  struct sockaddr_storage addr_storage;
  int err = sockaddr_for_family(family, address.c_str(), port, &addr_storage);
  if (err == 0) {
    err = uv_udp_bind(&handle_,
                      reinterpret_cast<const sockaddr*>(&addr_storage), flags);
  }

  if (err == 0) listener()->OnAfterBind();

  return err;
}

int UDPWrap::DoConnect(const std::string& address, uint16_t port, int family)
{
  struct sockaddr_storage addr_storage;
  int err = sockaddr_for_family(family, address.c_str(), port,
  &addr_storage); if (err == 0) {
    err = uv_udp_connect(&handle_,
                         reinterpret_cast<const sockaddr*>(&addr_storage));
  }

  return err;
}

int UDPWrap::Open(int fd) {
  int err = uv_udp_open(&handle_, fd);
  return err;
}

int UDPWrap::Bind(const std::string& address, uint16_t port, uint32_t flags) {
  return DoBind(address, port, flags, AF_INET);
}

int UDPWrap::Bind6(const std::string& address, uint16_t port, uint32_t flags) {
  return DoBind(address, port, flags, AF_INET6);
}

int UDPWrap::BufferSize(int32_t size, bool is_recv) {
  // const char* uv_func_name =
  //     is_recv ? "uv_recv_buffer_size" : "uv_send_buffer_size";

  uv_handle_t* handle = reinterpret_cast<uv_handle_t*>(&handle_);

  int err;

  if (is_recv)
    err = uv_recv_buffer_size(handle, &size);
  else
    err = uv_send_buffer_size(handle, &size);

  return err;
}

int UDPWrap::Connect(const std::string& address, uint16_t port) {
  return DoConnect(address, port, AF_INET);
}

int UDPWrap::Connect6(const std::string& address, uint16_t port) {
  return DoConnect(address, port, AF_INET6);
}

int UDPWrap::Disconnect() {
  int err = uv_udp_connect(&handle_, nullptr);

  return err;
}

int UDPWrap::SetMulticastInterface(const std::string& iface) {
  int err = uv_udp_set_multicast_interface(&handle_, iface.c_str());
  return err;
}

int UDPWrap::SetMembership(const std::string& address, const std::string& iface,
                           uv_membership membership) {
  const char* iface_cstr = iface.c_str();
  if (iface.empty()) {
    iface_cstr = nullptr;
  }

  int err =
      uv_udp_set_membership(&handle_, address.c_str(), iface_cstr, membership);
  return err;
}

int UDPWrap::AddMembership(const std::string& address,
                           const std::string& iface) {
  return SetMembership(address, iface, UV_JOIN_GROUP);
}

int UDPWrap::DropMembership(const std::string& address,
                            const std::string& iface) {
  return SetMembership(address, iface, UV_LEAVE_GROUP);
}

int UDPWrap::SetSourceMembership(const std::string& source_address,
                                 const std::string& group_address,
                                 const std::string& iface,
                                 uv_membership membership) {
  const char* iface_cstr = iface.c_str();
  if (iface.empty()) {
    iface_cstr = nullptr;
  }

  int err =
      uv_udp_set_source_membership(&handle_, group_address.c_str(), iface_cstr,
                                   source_address.c_str(), membership);
  return err;
}

int UDPWrap::AddSourceSpecificMembership(const std::string& source_address,
                                         const std::string& group_address,
                                         const std::string& iface) {
  return SetSourceMembership(source_address, group_address, iface,
                             UV_JOIN_GROUP);
}

int UDPWrap::DropSourceSpecificMembership(const std::string& source_address,
                                          const std::string& group_address,
                                          const std::string& iface) {
  return SetSourceMembership(source_address, group_address, iface,
                             UV_LEAVE_GROUP);
}

// void UDPWrap::DoSend(const FunctionCallbackInfo<Value>& args, int family) {
//   Environment* env = Environment::GetCurrent(args);

//   UDPWrap* wrap;
//   ASSIGN_OR_RETURN_UNWRAP(
//       &wrap, args.This(), args.GetReturnValue().Set(UV_EBADF));

//   CHECK(args.Length() == 4 || args.Length() == 6);
//   CHECK(args[0]->IsObject());
//   CHECK(args[1]->IsArray());
//   CHECK(args[2]->IsUint32());

//   bool sendto = args.Length() == 6;
//   if (sendto) {
//     // send(req, list, list.length, port, address, hasCallback)
//     CHECK(args[3]->IsUint32());
//     CHECK(args[4]->IsString());
//     CHECK(args[5]->IsBoolean());
//   } else {
//     // send(req, list, list.length, hasCallback)
//     CHECK(args[3]->IsBoolean());
//   }

//   Local<Array> chunks = args[1].As<Array>();
//   // it is faster to fetch the length of the
//   // array in js-land
//   size_t count = args[2].As<Uint32>()->Value();

//   MaybeStackBuffer<uv_buf_t, 16> bufs(count);

//   // construct uv_buf_t array
//   for (size_t i = 0; i < count; i++) {
//     Local<Value> chunk;
//     if (!chunks->Get(env->context(), i).ToLocal(&chunk)) return;

//     size_t length = Buffer::Length(chunk);

//     bufs[i] = uv_buf_init(Buffer::Data(chunk), length);
//   }

// int err = 0;
// struct sockaddr_storage addr_storage;
// sockaddr* addr = nullptr;
// if (sendto) {
//   const unsigned short port = args[3].As<Uint32>()->Value();
//   node::Utf8Value address(env->isolate(), args[4]);
//   err = sockaddr_for_family(family, address.out(), port, &addr_storage);
//   if (err == 0) addr = reinterpret_cast<sockaddr*>(&addr_storage);
// }

//   if (err == 0) {
//     wrap->current_send_req_wrap_ = args[0].As<Object>();
//     wrap->current_send_has_callback_ =
//         sendto ? args[5]->IsTrue() : args[3]->IsTrue();

//     err = static_cast<int>(wrap->Send(*bufs, count, addr));

//     wrap->current_send_req_wrap_.Clear();
//     wrap->current_send_has_callback_ = false;
//   }

//   args.GetReturnValue().Set(err);
// }

int UDPWrap::DoSend(uv_buf_t* bufs_ptr, int count, bool hasCallback,
                    int family) {
  // construct uv_buf_t array
  int err = 0;
  sockaddr* addr = nullptr;

  // current_send_req_wrap_ = args[0].As<Object>();

  current_send_has_callback_ = hasCallback;

  err = static_cast<int>(Send(bufs_ptr, count, addr));

  // current_send_req_wrap_.Clear();

  current_send_has_callback_ = false;

  return (err);
}

int UDPWrap::DoSendto(uv_buf_t* bufs_ptr, int count, uint16_t port,
                      const std::string& address, bool hasCallback,
                      int family) {
  // construct uv_buf_t array
  int err = 0;
  struct sockaddr_storage addr_storage;
  sockaddr* addr = nullptr;
  err = sockaddr_for_family(family, address.c_str(), port, &addr_storage);
  if (err == 0) addr = reinterpret_cast<sockaddr*>(&addr_storage);

  if (err == 0) {
    // current_send_req_wrap_ = args[0].As<Object>();
    current_send_has_callback_ = hasCallback;

    err = static_cast<int>(Send(bufs_ptr, count, addr));

    // current_send_req_wrap_.Clear();
    current_send_has_callback_ = false;
  }

  return (err);
}

ssize_t UDPWrap::Send(uv_buf_t* bufs_ptr, size_t count, const sockaddr* addr) {
  if (IsHandleClosing()) return UV_EBADF;

  size_t msg_size = 0;
  for (size_t i = 0; i < count; i++) msg_size += bufs_ptr[i].len;

  int err = 0;
  err = uv_udp_try_send(&handle_, bufs_ptr, count, addr);
  if (err == UV_ENOSYS || err == UV_EAGAIN) {
    err = 0;
  } else if (err >= 0) {
    size_t sent = err;
    while (count > 0 && bufs_ptr->len <= sent) {
      sent -= bufs_ptr->len;
      bufs_ptr++;
      count--;
    }
    if (count > 0) {
      CHECK_LT(sent, bufs_ptr->len);
      bufs_ptr->base += sent;
      bufs_ptr->len -= sent;
    } else {
      CHECK_EQ(static_cast<size_t>(err), msg_size);
      // + 1 so that the JS side can distinguish 0-length async sends from
      // 0-length sync sends.
      return msg_size + 1;
    }
  }

  if (err == 0) {
    ReqWrap<uv_udp_send_t>* req_wrap = listener()->CreateSendWrap(msg_size);
    if (req_wrap == nullptr) return UV_ENOSYS;

    err = req_wrap->Dispatch(
        uv_udp_send, &handle_, bufs_ptr, count, addr,
        uv_udp_send_cb{[](uv_udp_send_t* req, int status) {
          UDPWrap* self = ContainerOf(&UDPWrap::handle_, req->handle);
          self->listener()->OnSendDone(ReqWrap<uv_udp_send_t>::from_req(req),
                                       status);
        }});
    if (err) delete req_wrap;
  }
  return err;
}

ReqWrap<uv_udp_send_t>* UDPWrap::CreateSendWrap(size_t msg_size) {
  SendWrap* req_wrap = new SendWrap(current_send_has_callback_);
  req_wrap->msg_size = msg_size;
  return req_wrap;
}

// void UDPWrap::Send(const FunctionCallbackInfo<Value>& args) {
//   DoSend(args, AF_INET);
// }

// void UDPWrap::Send6(const FunctionCallbackInfo<Value>& args) {
//   DoSend(args, AF_INET6);
// }

SocketAddress UDPWrap::GetPeerName() {
  return SocketAddress::FromPeerName(handle_);
}

SocketAddress UDPWrap::GetSockName() {
  return SocketAddress::FromSockName(handle_);
}

int UDPWrap::RecvStart() {
  if (IsHandleClosing()) return UV_EBADF;
  int err = uv_udp_recv_start(&handle_, OnAlloc, OnRecv);
  // UV_EALREADY means that the socket is already bound but that's okay
  if (err == UV_EALREADY) err = 0;
  return err;
}

int UDPWrap::RecvStop() {
  if (IsHandleClosing()) return UV_EBADF;
  return uv_udp_recv_stop(&handle_);
}

void UDPWrap::OnSendDone(ReqWrap<uv_udp_send_t>* req, int status) {
  SendWrap* req_wrap = static_cast<SendWrap*>(req);
  if (req_wrap->have_callback()) {
    // Environment* env = req_wrap->env();
    // HandleScope handle_scope(env->isolate());
    // Context::Scope context_scope(env->context());
    // Local<Value> arg[] = {
    //     Integer::New(env->isolate(), status),
    //     Integer::New(env->isolate(), req_wrap->msg_size),
    // };
    // req_wrap->MakeCallback(env->oncomplete_string(), 2, arg);
  }
}

void UDPWrap::OnAlloc(uv_handle_t* handle, size_t suggested_size,
                      uv_buf_t* buf) {
  UDPWrap* wrap =
      ContainerOf(&UDPWrap::handle_, reinterpret_cast<uv_udp_t*>(handle));
  *buf = wrap->listener()->OnAlloc(suggested_size);
}

uv_buf_t UDPWrap::OnAlloc(size_t suggested_size) {
  // std::unique_ptr<v8::BackingStore> bs =
  // v8::ArrayBuffer::NewBackingStore(isolate(), suggested_size);

  // TODO FIX me
  char* data = new char[suggested_size];
  uv_buf_t buf = uv_buf_init(static_cast<char*>(data), suggested_size);

  return buf;
}

void UDPWrap::OnRecv(uv_udp_t* handle, ssize_t nread, const uv_buf_t* buf,
                     const sockaddr* addr, unsigned int flags) {
  UDPWrap* wrap = ContainerOf(&UDPWrap::handle_, handle);
  wrap->listener()->OnRecv(nread, *buf, addr, flags);
}

void UDPWrap::OnRecv(ssize_t nread, const uv_buf_t& buf_, const sockaddr* addr,
                     unsigned int flags) {
  // std::unique_ptr<BackingStore> bs = env->release_managed_buffer(buf_);
  if (nread == 0 && addr == nullptr) {
    return;
  }

  if (nread < 0) {
    // MakeCallback(env->onmessage_string(), arraysize(argv), argv);
    return;
  } else if (nread == 0) {
    // bs = ArrayBuffer::NewBackingStore(isolate, 0);
  } else {
    // CHECK_LE(static_cast<size_t>(nread), bs->ByteLength());
    //  bs = BackingStore::Reallocate(isolate, std::move(bs), nread);
  }
}

size_t UDPWrap::GetSendQueueSize() {
  size_t size = uv_udp_get_send_queue_size(&handle_);
  return (size);
}

size_t UDPWrap::GetSendQueueCount() {
  size_t count = uv_udp_get_send_queue_count(&handle_);
  return count;
}
