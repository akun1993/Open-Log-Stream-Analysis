#ifndef SRC_CRYPTO_CRYPTO_COMMON_H_
#define SRC_CRYPTO_CRYPTO_COMMON_H_

#include <openssl/ssl.h>
#include <openssl/x509v3.h>

#include <memory>
#include <string>

#include "crypto_context.h"
#include "crypto_util.h"

namespace crypto {

typedef struct CipherInfo {
  std::string cipherName;
  std::string cipherStandardName;
  std::string cipherVersion;
} CipherInfo;

typedef struct X509Info {
  std::string subject;
  std::string issuer;
  std::string subjectaltname;
  std::string infoaccess;
  bool is_ca;

  bool is_rsa;
  bool is_ec;

  std::string modulus;
  std::string bits;
  std::string exponent;
  std::vector<uint8_t> pubkey;

  std::string asn1curve;
  std::string nistcurve;

  std::string valid_from;
  std::string valid_to;

  std::string fingerprint;
  std::string fingerprint256;
  std::string fingerprint512;
  std::vector<std::string> ext_key_usage;
  std::string serial_number;
  // RawDERCertificate
  std::vector<uint8_t> rawDERCert;

  X509Info* issuercert;

} X509Info;

typedef struct EphemeralKey {
  int kid;
  int kBitSize;

  std::string curve_name;

} EphemeralKey;

struct StackOfX509Deleter {
  void operator()(STACK_OF(X509) * p) const { sk_X509_pop_free(p, X509_free); }
};

using StackOfX509 = std::unique_ptr<STACK_OF(X509), StackOfX509Deleter>;

struct StackOfXASN1Deleter {
  void operator()(STACK_OF(ASN1_OBJECT) * p) const {
    sk_ASN1_OBJECT_pop_free(p, ASN1_OBJECT_free);
  }
};
using StackOfASN1 = std::unique_ptr<STACK_OF(ASN1_OBJECT), StackOfXASN1Deleter>;

X509Pointer SSL_CTX_get_issuer(SSL_CTX* ctx, X509* cert);

void LogSecret(const SSLPointer& ssl, const char* name,
               const unsigned char* secret, size_t secretlen);

std::string GetSSLOCSPResponse(SSL* ssl);

bool SetTLSSession(const SSLPointer& ssl, const SSLSessionPointer& session);

SSLSessionPointer GetTLSSession(const unsigned char* buf, size_t length);

long VerifyPeerCertificate(  // NOLINT(runtime/int)
    const SSLPointer& ssl,
    long def = X509_V_ERR_UNSPECIFIED);  // NOLINT(runtime/int)

bool UseSNIContext(const SSLPointer& ssl, SecureContext* context);

const char* GetClientHelloALPN(const SSLPointer& ssl);

const char* GetClientHelloServerName(const SSLPointer& ssl);

const char* GetServerName(SSL* ssl);

std::vector<CipherInfo> GetClientHelloCiphers(const SSLPointer& ssl);

bool SetGroups(SecureContext* sc, char* groups);

const char* X509ErrorCode(long err);  // NOLINT(runtime/int)

const char* GetValidationErrorReason(int err);

const char* GetValidationErrorCode(int err);

X509* GetCert(const SSLPointer& ssl);

CipherInfo GetCipherInfo(const SSLPointer& ssl);

EphemeralKey GetEphemeralKey(const SSLPointer& ssl);

void GetPeerCert(const SSLPointer& ssl,
                                      bool abbreviated = false,
                                      bool is_server = false);

std::vector<uint8_t> ECPointToBuffer(const EC_GROUP* group,
                                     const EC_POINT* point,
                                     point_conversion_form_t form,
                                     const char** error);

X509Info X509ToObject(X509* cert);

std::string GetValidTo(X509* cert, const BIOPointer& bio);

std::string GetValidFrom(X509* cert, const BIOPointer& bio);

std::string GetFingerprintDigest(const EVP_MD* method, X509* cert);

std::vector<std::string> GetKeyUsage(X509* cert);
std::string GetCurrentCipherName(const SSLPointer& ssl);
std::string GetCurrentCipherVersion(const SSLPointer& ssl);

std::string GetSerialNumber(X509* cert);

std::vector<uint8_t> GetRawDERCertificate(X509* cert);

// v8::Local<v8::Value> ToV8Value(const BIOPointer& bio);
bool SafeX509SubjectAltNamePrint(const BIOPointer& out, X509_EXTENSION* ext);

std::string GetSubject(X509* cert, const BIOPointer& bio);

std::string GetIssuerString(X509* cert, const BIOPointer& bio);

std::string GetSubjectAltNameString(X509* cert, const BIOPointer& bio);

std::string GetInfoAccessString(X509* cert, const BIOPointer& bio);

}  // namespace crypto

#endif  // SRC_CRYPTO_CRYPTO_COMMON_H_
