
#include "clock_queue_base.h"
#include "loop_wrap.h"
#include "time_tick.h"
#include "util-inl.h"
#include <assert.h>
#include <sys/timerfd.h>
#include <unistd.h>
#include <string.h>


int createTimerfd(clockid_t clkId) {
    int timerfd = ::timerfd_create(clkId, TFD_NONBLOCK | TFD_CLOEXEC);
    if (timerfd < 0) {
        printf("[%s] Failed to create timerfd %d\n", __FUNCTION__,timerfd);
    }
    return timerfd;
}

struct timespec howMuchTimeFromNow(Timetick when) {
    int64_t microseconds = when.microSecondsTicks() - Timetick::now().microSecondsTicks();
    if (microseconds < 100) {
        microseconds = 100;
    }
    struct timespec ts;
    ts.tv_sec = static_cast<time_t>(microseconds / Timetick::kMicroSecondsPerSecond);
    ts.tv_nsec = static_cast<long>((microseconds % Timetick::kMicroSecondsPerSecond) * 1000);
    return ts;
}

void readTimerfd(int timerfd) {
    uint64_t howmany;
    ssize_t n = ::read(timerfd, &howmany, sizeof howmany);

    if (n != sizeof howmany) {
        printf("[readTimerfd] return size %ld not equal %lu \n", n, sizeof howmany);
    }
}

void resetTimerfd(int timerfd, Timetick expiration) {
    // wake up loop by timerfd_settime()
    struct itimerspec newValue;
    struct itimerspec oldValue;
    (void)memset(&newValue, 0, sizeof newValue);
    (void)memset(&oldValue, 0, sizeof oldValue);
    newValue.it_value = howMuchTimeFromNow(expiration);
    int ret = ::timerfd_settime(timerfd, 0, &newValue, &oldValue);
    if (ret) {
        printf("[resetTimerfd] set time return %d ", ret);
    }
}


void poll_cb(uv_poll_t* watcher, int status, int events) {

    if (events & UV_READABLE) {
        ClockQueueBase* clkBase = ContainerOf(&ClockQueueBase::poll_handle_, watcher);

        clkBase->handleRead(watcher,status,events);
    }
    
}

ClockQueueBase::ClockQueueBase(LoopWrap* loop,clockid_t clockid)
    : loop_(loop), timerfd_(createTimerfd(clockid)), callingExpiredTimers_(false) {
    uv_poll_init(loop_->handle(), &poll_handle_, timerfd_);
    uv_poll_start(&poll_handle_, UV_READABLE , poll_cb);
}

ClockQueueBase::~ClockQueueBase() {
    uv_poll_stop(&poll_handle_);
    (void)::close(timerfd_);
    for (const Entry& timer : timers_) {
        delete timer.second;
    }    
}



TimerId ClockQueueBase::addTimer(TimerCallback cb, Timetick when, double interval) {
    Timer* timer = new Timer(std::move(cb), when, interval);
    loop_->runInThisLoop(std::bind(&ClockQueueBase::addTimerInLoop, this, timer));
    return TimerId(timer, timer->sequence());
}

void ClockQueueBase::cancel(TimerId timerId) {
    loop_->runInThisLoop(std::bind(&ClockQueueBase::cancelInLoop, this, timerId));
}

void ClockQueueBase::addTimerInLoop(Timer* timer) {
   // loop_->assertInLoopThread();
    bool earliestChanged = insert(timer);

    if (earliestChanged) {
        resetTimerfd(timerfd_, timer->expiration());
    }
}

void ClockQueueBase::cancelInLoop(TimerId timerId) {

    assert(timers_.size() == activeTimers_.size());
    ActiveTimer timer(timerId.timer_, timerId.sequence_);
    ActiveTimerSet::iterator it = activeTimers_.find(timer);
    if (it != activeTimers_.end()) {
        size_t n = timers_.erase(Entry(it->first->expiration(), it->first));
        assert(n == 1);
        (void)n;
        delete it->first;  // FIXME: no delete please
        (void)activeTimers_.erase(it);
    } else if (callingExpiredTimers_) {
        (void)cancelingTimers_.insert(timer);
    }
    assert(timers_.size() == activeTimers_.size());
}

void ClockQueueBase::handleRead(uv_poll_t* poll, int status, int events) {
   // loop_->assertInLoopThread();
    Timetick now(Timetick::now());
    
    readTimerfd(timerfd_);

    std::vector<Entry> expired = getExpired(now);

    callingExpiredTimers_ = true;
    cancelingTimers_.clear();
    // safe to callback outside critical section
    for (const Entry& it : expired) {
        it.second->run();
    }
    callingExpiredTimers_ = false;

    reset(expired, now);
}


std::vector<ClockQueueBase::Entry> ClockQueueBase::getExpired(Timetick now) {
    assert(timers_.size() == activeTimers_.size());
    std::vector<Entry> expired;
    Entry sentry(now, reinterpret_cast<Timer*>(UINTPTR_MAX));
    TimerList::iterator end = timers_.lower_bound(sentry);
    assert(end == timers_.end() || now < end->first);
    (void)std::copy(timers_.begin(), end, back_inserter(expired));
    (void)timers_.erase(timers_.begin(), end);

    for (const Entry& it : expired) {
        ActiveTimer timer(it.second, it.second->sequence());
        size_t n = activeTimers_.erase(timer);
        assert(n == 1);
        (void)n;
    }

    assert(timers_.size() == activeTimers_.size());
    return expired;
}



void ClockQueueBase::reset(const std::vector<Entry>& expired, Timetick now) {
    Timetick nextExpire;

    for (const Entry& it : expired) {
        ActiveTimer timer(it.second, it.second->sequence());
        if (it.second->repeat() && cancelingTimers_.find(timer) == cancelingTimers_.end()) {
            it.second->restart(now);
            (void)insert(it.second);
        } else {
            // FIXME move to a free list
            delete it.second;  // FIXME: no delete please
        }
    }

    if (!timers_.empty()) {
        nextExpire = timers_.begin()->second->expiration();
    }

    if (nextExpire.valid()) {
        resetTimerfd(timerfd_, nextExpire);
    }
}

bool ClockQueueBase::insert(Timer* timer) {
    //loop_->assertInLoopThread();
    assert(timers_.size() == activeTimers_.size());
    bool earliestChanged = false;
    Timetick when = timer->expiration();
    TimerList::iterator it = timers_.begin();
    if (it == timers_.end() || when < it->first) {
        earliestChanged = true;
    }
    {
        std::pair<TimerList::iterator, bool> result = timers_.insert(Entry(when, timer));
        assert(result.second);
        (void)result;
    }
    {
        std::pair<ActiveTimerSet::iterator, bool> result = activeTimers_.insert(ActiveTimer(timer, timer->sequence()));
        assert(result.second);
        (void)result;
    }

    assert(timers_.size() == activeTimers_.size());
    return earliestChanged;
}

