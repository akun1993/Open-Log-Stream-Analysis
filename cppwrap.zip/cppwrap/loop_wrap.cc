
#include "loop_wrap.h"
#include "current_thread.h"

uv_loop_t * create_new_loop(){
    uv_loop_t *loop = new uv_loop_t();
    uv_loop_init(loop);
    return loop;
}

LoopWrap::LoopWrap():loop_(create_new_loop()), 
                realClock_(this,CLOCK_REALTIME),
                alarmClock_(this,CLOCK_BOOTTIME_ALARM),
                monotonicClock_(this,CLOCK_MONOTONIC),
                boottimeClock_(this,CLOCK_BOOTTIME_ALARM)
{
    asyncInit(); 
}

LoopWrap::LoopWrap(bool use_def):loop_(uv_default_loop()), 
                                realClock_(this,CLOCK_REALTIME),
                                alarmClock_(this,CLOCK_BOOTTIME_ALARM),
                                monotonicClock_(this,CLOCK_MONOTONIC),
                                boottimeClock_(this,CLOCK_BOOTTIME_ALARM)
{
    asyncInit();
}

LoopWrap::~LoopWrap(){
    if (loop_ != uv_default_loop()){   
        uv_loop_close(loop_);
        delete loop_;
    }
}

LoopWrap& LoopWrap::defaultLoop(){
    static LoopWrap defaultLoop(true);
    return defaultLoop;
}

uv_loop_t* LoopWrap::handle(){
    return loop_;
}

void LoopWrap::asyncInit(){
    threadId_ = ThisThread::threadId();
    uv_async_init(loop_, &task_queues_async_,asyncCallback);
    task_queues_async_.data = static_cast<void*>(this);
}

int LoopWrap::run()
{
    if (!is_running_){
        is_running_ = true;
        auto rst = ::uv_run(loop_, UV_RUN_DEFAULT);
        is_running_ = false;
        return rst;
    }
    return -1;
}


int LoopWrap::stop(){
    if (is_running_){
        if (uv_is_closing((uv_handle_t*)&task_queues_async_) == 0){
            uv_close((uv_handle_t*)&task_queues_async_, [](uv_handle_t* handle){
                ::uv_stop(uv_handle_get_loop(handle));
            });
        }
        return 0;
    }
    return -1;
}


bool LoopWrap::isInLoopThread(){
    if (is_running_ ){
        return ThisThread::threadId() == threadId_;
    }
    return false;
}

void LoopWrap::runInThisLoop( Functor func){
    if (nullptr == func)
        return;

    if (isInLoopThread()){
        func();
        return;
    }
    
    {
        std::lock_guard<std::mutex> lock(mutex_);
        callbacks_.push_back(std::move(func));
    }

    if (!isInLoopThread() || callingPendingFunctors_) {
        uv_async_send(&task_queues_async_);
    }
}


TimerId LoopWrap::runAt(Timetick time, TimerCallback cb) {
    return monotonicClock_.addTimer(std::move(cb), time, 0.0);
}

TimerId LoopWrap::runAfter(double delay, TimerCallback cb) {
    Timetick time(addTime(Timetick::now(), delay));
    return runAt(time, std::move(cb));
}

TimerId LoopWrap::runEvery(double interval, TimerCallback cb) {
    Timetick time(addTime(Timetick::now(), interval));
    return monotonicClock_.addTimer(std::move(cb), time, interval);
}

void LoopWrap::cancel(TimerId timerId) {
    return monotonicClock_.cancel(timerId);
}


void LoopWrap::asyncCallback(uv_async_t* handle){
    printf("asyncCallback\n");
    auto loop = static_cast<LoopWrap*>(handle->data);
    std::vector<Functor> functors;
    loop->callingPendingFunctors_ = true;
    {
        std::lock_guard<std::mutex> lock(loop->mutex_);
        functors.swap(loop->callbacks_);
    }
    for (const Functor& functor : functors){
      functor();
    }
    loop->callingPendingFunctors_ = false;
}

const char* LoopWrap::getErrorMessage(int status){
    return uv_strerror(status);
}