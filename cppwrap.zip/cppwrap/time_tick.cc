

#include "time_tick.h"
#include <sys/time.h>
#include <stdio.h>

#ifndef __STDC_FORMAT_MACROS
#define __STDC_FORMAT_MACROS
#endif

#include <inttypes.h>

static_assert(sizeof(Timetick) == sizeof(int64_t), "Timetick  should be int64_t");

std::string Timetick::toString() const {
    char buf[32] = {0};
    int64_t seconds = microSecondsTicks_ / kMicroSecondsPerSecond;
    int64_t microseconds = microSecondsTicks_ % kMicroSecondsPerSecond;
    (void)snprintf(buf, sizeof(buf), "%" PRId64 ".%06" PRId64 "", seconds, microseconds);
    return buf;
}

Timetick Timetick::now() {
    struct timespec ts;
    (void)clock_gettime(CLOCK_MONOTONIC_COARSE, &ts);

    int64_t seconds = ts.tv_sec;
    return Timetick(seconds * kMicroSecondsPerSecond + ts.tv_nsec / 1000);
}
