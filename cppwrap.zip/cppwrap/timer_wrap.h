
#ifndef SRC_TIMER_WRAP_H_
#define SRC_TIMER_WRAP_H_

#include "uv.h"
#include <functional>
#include <atomic>

class LoopWrap;

class TimerWrap {
public:
    using TimerCb = std::function<void()>;

    TimerWrap(LoopWrap *loop,TimerCb fn);

    TimerWrap(const TimerWrap&) = delete;
    TimerWrap(const TimerWrap&&) = delete;

        // Stop calling the timer callback.
    void Stop();
    // Render the timer unusable and delete this object.
    void Close();

    // Starts / Restarts the Timer
    void Update(uint64_t interval, uint64_t repeat = 0);

    void Ref(); 
    
    void Unref();

private:
    static void OnTimeout(uv_timer_t* timer) ;
    static void TimerClosedCb(uv_handle_t* handle);

    TimerCb fn_;
    uv_timer_t timer_;
    //const int64_t seq_;

    static std::atomic<int64_t>  timer_num_seq_;
};

#endif
