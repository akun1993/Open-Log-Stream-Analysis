// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

#ifndef SRC_UDP_WRAP_H_
#define SRC_UDP_WRAP_H_

#include "handle_wrap.h"
#include "node_sockaddr.h"
#include "req_wrap.h"
#include "uv.h"

class UDPWrapBase;

// A listener that can be attached to an `UDPWrapBase` object and generally
// manages its I/O activity. This is similar to `StreamListener`.
class UDPListener {
 public:
  virtual ~UDPListener();

  // Called right before data is received from the socket. Must return a
  // buffer suitable for reading data into, that is then passed to OnRecv.
  virtual uv_buf_t OnAlloc(size_t suggested_size) = 0;

  // Called right after data is received from the socket, and includes
  // information about the source address. If `nread` is negative, an error
  // has occurred, and it represents a libuv error code.
  virtual void OnRecv(ssize_t nread, const uv_buf_t& buf, const sockaddr* addr,
                      unsigned int flags) = 0;

  // Called when an asynchronous request for writing data is created.
  // The `msg_size` value contains the total size of the data to be sent,
  // but may be ignored by the implementation of this Method.
  // The return value is later passed to OnSendDone.
  virtual ReqWrap<uv_udp_send_t>* CreateSendWrap(size_t msg_size) = 0;

  // Called when an asynchronous request for writing data has finished.
  // If status is negative, an error has occurred, and it represents a libuv
  // error code.
  virtual void OnSendDone(ReqWrap<uv_udp_send_t>* wrap, int status) = 0;

  // Optional callback that is called after the socket has been bound.
  virtual void OnAfterBind() {}

  inline UDPWrapBase* udp() const { return wrap_; }

 protected:
  UDPWrapBase* wrap_ = nullptr;

  friend class UDPWrapBase;
};

class UDPWrapBase {
 public:
  virtual ~UDPWrapBase();

  // Start emitting OnAlloc() + OnRecv() events on the listener.
  virtual int RecvStart() = 0;

  // Stop emitting OnAlloc() + OnRecv() events on the listener.
  virtual int RecvStop() = 0;

  // Send a chunk of data over this socket. This may call CreateSendWrap()
  // on the listener if an async transmission is necessary.
  virtual ssize_t Send(uv_buf_t* bufs, size_t nbufs, const sockaddr* addr) = 0;

  virtual SocketAddress GetPeerName() = 0;
  virtual SocketAddress GetSockName() = 0;

  void set_listener(UDPListener* listener);
  UDPListener* listener() const;

  // static void RecvStart(const v8::FunctionCallbackInfo<v8::Value>& args);
  // static void RecvStop(const v8::FunctionCallbackInfo<v8::Value>& args);

 private:
  UDPListener* listener_ = nullptr;
};

class UDPWrap final : public HandleWrap,
                      public UDPWrapBase,
                      public UDPListener {
 public:
  enum SocketType { SOCKET };

  int GetFD();
  // void New(const v8::FunctionCallbackInfo<v8::Value>& args);
  int Open(int fd);
  int Bind(const std::string& address, uint16_t port, uint32_t flags);
  int Connect(const std::string& address, uint16_t port);
  // ssize_t Send(uv_buf_t* bufs_ptr, size_t count, const sockaddr* addr);
  int Bind6(const std::string& address, uint16_t port, uint32_t flags);
  int Connect6(const std::string& address, uint16_t port);
  ssize_t Send6(uv_buf_t* bufs_ptr, size_t count, const sockaddr* addr);

  int Disconnect();

  int AddMembership(const std::string& address, const std::string& iface);
  int DropMembership(const std::string& address, const std::string& iface);
  int AddSourceSpecificMembership(const std::string& source_address,
                                  const std::string& group_address,
                                  const std::string& iface);
  int DropSourceSpecificMembership(const std::string& source_address,
                                   const std::string& group_address,
                                   const std::string& iface);

  int SetMulticastInterface(const std::string& iface);

  int BufferSize(int32_t size, bool is_recv);
  size_t GetSendQueueSize();
  size_t GetSendQueueCount();

  // UDPListener implementation
  uv_buf_t OnAlloc(size_t suggested_size) override;
  void OnRecv(ssize_t nread, const uv_buf_t& buf, const sockaddr* addr,
              unsigned int flags) override;

  ReqWrap<uv_udp_send_t>* CreateSendWrap(size_t msg_size) override;
  void OnSendDone(ReqWrap<uv_udp_send_t>* wrap, int status) override;

  // UDPWrapBase implementation
  int RecvStart() override;
  int RecvStop() override;
  ssize_t Send(uv_buf_t* bufs, size_t nbufs, const sockaddr* addr) override;

  SocketAddress GetPeerName() override;
  SocketAddress GetSockName() override;

  inline uv_udp_t* GetLibuvHandle() { return &handle_; }

 private:
  typedef uv_udp_t HandleType;

  UDPWrap(uv_loop_t* loop);

  int DoBind(const std::string& address, uint16_t port, uint32_t flags,
             int family);
  int DoConnect(const std::string& address, uint16_t port, int family);
  int DoSend(uv_buf_t* bufs_ptr, int count, bool hasCallback, int family);
  int DoSendto(uv_buf_t* bufs_ptr, int count, uint16_t port,
               const std::string& address, bool hasCallback, int family);

  int SetMembership(const std::string& address, const std::string& iface,
                    uv_membership membership);
  int SetSourceMembership(const std::string& source_address,
                          const std::string& group_address,
                          const std::string& iface, uv_membership membership);

  static void OnAlloc(uv_handle_t* handle, size_t suggested_size,
                      uv_buf_t* buf);
  static void OnRecv(uv_udp_t* handle, ssize_t nread, const uv_buf_t* buf,
                     const struct sockaddr* addr, unsigned int flags);

  uv_udp_t handle_;

  bool current_send_has_callback_;
  // v8::Local<v8::Object> current_send_req_wrap_;
};

int sockaddr_for_family(int address_family, const char* address,
                        const unsigned short port, sockaddr_storage* addr);

#endif  // SRC_UDP_WRAP_H_
