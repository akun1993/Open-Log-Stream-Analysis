// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

#include "pipe_wrap.h"

#include "connect_wrap.h"
#include "connection_wrap.h"
#include "handle_wrap.h"
#include "stream_base-inl.h"
#include "stream_wrap.h"
#include "util-inl.h"

// void PipeWrap::New(int type) {
//   PipeWrap::SocketType _type = static_cast<PipeWrap::SocketType>(type);

//   bool ipc;
//   switch (_type) {
//     case SOCKET:
//       ipc = false;
//       break;
//     case SERVER:
//       ipc = false;
//       break;
//     case IPC:
//       ipc = true;
//       break;
//     default:
//       UNREACHABLE();
//   }

//   new PipeWrap(ipc);
// }

PipeWrap::PipeWrap(uv_loop_t *loop,bool ipc) : ConnectionWrap() {
  int r = uv_pipe_init(loop, &handle_, ipc);
  CHECK_EQ(r, 0);  // How do we proxy this error up to javascript?
                   // Suggestion: uv_pipe_init() returns void.
}

int PipeWrap::Bind(const std::string& name) {
  int err = uv_pipe_bind(&handle_, name.c_str());
  return err;
}

#ifdef _WIN32
void PipeWrap::SetPendingInstances(int instances) {
  uv_pipe_pending_instances(&handle_, instances);
}
#endif

// int PipeWrap::Fchmod(int mode) {
//   int err = uv_pipe_chmod(&handle_, mode);
//   return err;
// }

int PipeWrap::Listen(int backlog) {
  int err = uv_listen(reinterpret_cast<uv_stream_t*>(&handle_), backlog,
                      OnConnection);
  return err;
}

int PipeWrap::Open(int fd) {
  int err = uv_pipe_open(&handle_, fd);
  if (err == 0) set_fd(fd);

  return err;
}

int PipeWrap::Connect(const std::string& name) {
  ConnectWrap* req_wrap = new ConnectWrap();
  req_wrap->Dispatch(uv_pipe_connect, &handle_, name.c_str(), AfterConnect);

  return 0;
  // args.GetReturnValue().Set(0);  // uv_pipe_connect() doesn't return errors.
}
