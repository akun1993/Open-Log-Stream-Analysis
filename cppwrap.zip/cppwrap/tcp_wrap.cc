// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

#include "tcp_wrap.h"

#include <cstdlib>

#include "connect_wrap.h"
#include "connection_wrap.h"
#include "stream_base-inl.h"
#include "stream_wrap.h"
#include "util-inl.h"

TCPWrap::TCPWrap(uv_loop_t* loop) : ConnectionWrap() {
  int r = uv_tcp_init(loop, &handle_);
  CHECK_EQ(r, 0);  // How do we proxy this error up to javascript?
                   // Suggestion: uv_tcp_init() returns void.
}

int TCPWrap::SetNoDelay(bool enable) {
  int err = uv_tcp_nodelay(&handle_, enable);
  return (err);
}

int TCPWrap::SetKeepAlive(bool enable, uint32_t delay) {
  int err = uv_tcp_keepalive(&handle_, enable, delay);
  return (err);
}

#ifdef _WIN32
int TCPWrap::SetSimultaneousAccepts(bool enable) {
  int err = uv_tcp_simultaneous_accepts(&wrap->handle_, enable);
  return (err);
}
#endif

int TCPWrap::Open(int fd) {
  int err = uv_tcp_open(&handle_, fd);

  if (err == 0) set_fd(fd);

  return (err);
}

template <typename T>
int TCPWrap::Bind(
    const std::string& address, uint16_t port, uint32_t flags, int family,
    std::function<int(const char* ip_address, int port, T* addr)> uv_ip_addr) {
  T addr;
  int err = uv_ip_addr(address.c_str(), port, &addr);

  if (err == 0) {
    err = uv_tcp_bind(&handle_, reinterpret_cast<const sockaddr*>(&addr),
                      flags);
  }
  return (err);
}

int TCPWrap::Bind(const std::string& address, uint16_t port, uint32_t flags) {
  return Bind<sockaddr_in>(address, port, flags, AF_INET, uv_ip4_addr);
}

int TCPWrap::Bind6(const std::string& address, uint16_t port, uint32_t flags) {
  return Bind<sockaddr_in6>(address, port, flags, AF_INET6, uv_ip6_addr);
}

int TCPWrap::Listen(int backlog) {
  int err = uv_listen(reinterpret_cast<uv_stream_t*>(&handle_), backlog,
                      OnConnection);
  return err;
}

int TCPWrap::Connect(const std::string& address, uint16_t port) {
  // explicit cast to fit to libuv's type expectation
  return Connect<sockaddr_in>(
      address, [port](const char* ip_address, sockaddr_in* addr) {
        return uv_ip4_addr(ip_address, port, addr);
      });
}

int TCPWrap::Connect6(const std::string& address, uint16_t port) {
  return Connect<sockaddr_in6>(
      address, [port](const char* ip_address, sockaddr_in6* addr) {
        return uv_ip6_addr(ip_address, port, addr);
      });
}

template <typename T>
int TCPWrap::Connect(
    const std::string& address,
    std::function<int(const char* ip_address, T* addr)> uv_ip_addr) {
  T addr;
  int err = uv_ip_addr(address.c_str(), &addr);

  if (err == 0) {
    ConnectWrap* req_wrap = new ConnectWrap();
    err = req_wrap->Dispatch(uv_tcp_connect, &handle_,
                             reinterpret_cast<const sockaddr*>(&addr),
                             AfterConnect);
    if (err) {
      delete req_wrap;
    } else {
    }
  }

  return err;
}

int TCPWrap::Reset() {
  if (state_ != kInitialized) return 0;

  int err = uv_tcp_close_reset(&handle_, OnClose);
  state_ = kClosing;

  return err;
}
