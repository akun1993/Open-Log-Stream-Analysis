#include "connect_wrap.h"

#include "req_wrap-inl.h"

ConnectWrap::ConnectWrap() : ReqWrap() {}
