#ifndef SRC_CRYPTO_CRYPTO_KEYS_H_
#define SRC_CRYPTO_CRYPTO_KEYS_H_

#include <openssl/evp.h>

#include <memory>
#include <mutex>
#include <string>

#include "crypto_util.h"

namespace crypto {
enum PKEncodingType {
  //None
  kKeyEncodingNone,
  // RSAPublicKey / RSAPrivateKey according to PKCS#1.
  kKeyEncodingPKCS1,
  // PrivateKeyInfo or EncryptedPrivateKeyInfo according to PKCS#8.
  kKeyEncodingPKCS8,
  // SubjectPublicKeyInfo according to X.509.
  kKeyEncodingSPKI,
  // ECPrivateKey according to SEC1.
  kKeyEncodingSEC1
};

enum PKFormatType { kKeyFormatDER, kKeyFormatPEM, kKeyFormatJWK };

enum KeyType { kKeyTypeSecret, kKeyTypePublic, kKeyTypePrivate };

enum KeyEncodingContext {
  kKeyContextInput,
  kKeyContextExport,
  kKeyContextGenerate
};

enum class ParseKeyResult {
  kParseKeyOk,
  kParseKeyNotRecognized,
  kParseKeyNeedPassphrase,
  kParseKeyFailed
};

struct AsymmetricKeyEncodingConfig {
  bool output_key_object_ = false;
  PKFormatType format_ = kKeyFormatDER;
  PKEncodingType type_ = kKeyEncodingNone;
};

using PublicKeyEncodingConfig = AsymmetricKeyEncodingConfig;

struct PrivateKeyEncodingConfig : public AsymmetricKeyEncodingConfig {
  const EVP_CIPHER* cipher_;
  // The ByteSource alone is not enough to distinguish between "no passphrase"
  // and a zero-length passphrase (which can be a null pointer), therefore, we
  // use a NonCopyableMaybe.
  NonCopyableMaybe<ByteSource> passphrase_;
};

// This uses the built-in reference counter of OpenSSL to manage an EVP_PKEY
// which is slightly more efficient than using a shared pointer and easier to
// use.
class ManagedEVPPKey {
 public:
  ManagedEVPPKey() : mutex_(std::make_shared<std::mutex>()) {}
  explicit ManagedEVPPKey(EVPKeyPointer&& pkey);
  ManagedEVPPKey(const ManagedEVPPKey& that);
  ManagedEVPPKey& operator=(const ManagedEVPPKey& that);

  operator bool() const;
  EVP_PKEY* get() const;
  std::mutex* mutex() const;

  static ManagedEVPPKey ManagedEVPPKey::GetPublicOrPrivateKey(PrivateKeyEncodingConfig config, ByteSource &data);
  static ManagedEVPPKey GetParsedKey( EVPKeyPointer&& pkey,ParseKeyResult ret,const char* default_msg);

 private:
  size_t size_of_private_key() const;
  size_t size_of_public_key() const;

  EVPKeyPointer pkey_;
  std::shared_ptr<std::mutex> mutex_;
};

// Objects of this class can safely be shared among threads.
class KeyObjectData {
 public:
  static std::shared_ptr<KeyObjectData> CreateSecret(ByteSource key);

  static std::shared_ptr<KeyObjectData> CreateAsymmetric(
      KeyType type, const ManagedEVPPKey& pkey);

  KeyType GetKeyType() const;

  // These functions allow unprotected access to the raw key material and should
  // only be used to implement cryptographic operations requiring the key.
  ManagedEVPPKey GetAsymmetricKey() const;
  const char* GetSymmetricKey() const;
  size_t GetSymmetricKeySize() const;

 private:
  explicit KeyObjectData(ByteSource symmetric_key);

  KeyObjectData(KeyType type, const ManagedEVPPKey& pkey);

  const KeyType key_type_;
  const ByteSource symmetric_key_;
  const ManagedEVPPKey asymmetric_key_;
};

enum WebCryptoKeyFormat {
  kWebCryptoKeyFormatRaw,
  kWebCryptoKeyFormatPKCS8,
  kWebCryptoKeyFormatSPKI,
  kWebCryptoKeyFormatJWK
};

enum class WebCryptoKeyExportStatus { OK, INVALID_KEY_TYPE, FAILED };

WebCryptoKeyExportStatus PKEY_SPKI_Export(KeyObjectData* key_data,
                                          ByteSource* out);

WebCryptoKeyExportStatus PKEY_PKCS8_Export(KeyObjectData* key_data,
                                           ByteSource* out);

}  // namespace crypto

#endif  // SRC_CRYPTO_CRYPTO_KEYS_H_
