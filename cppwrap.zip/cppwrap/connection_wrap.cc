#include "connection_wrap.h"

#include "connect_wrap.h"
#include "pipe_wrap.h"
#include "stream_base-inl.h"
#include "stream_wrap.h"
#include "tcp_wrap.h"
#include "util-inl.h"

template <typename WrapType, typename UVType>
ConnectionWrap<WrapType, UVType>::ConnectionWrap()
    : LibuvStreamWrap(reinterpret_cast<uv_stream_t*>(&handle_)) {}

template <typename WrapType, typename UVType>
void ConnectionWrap<WrapType, UVType>::OnConnection(uv_stream_t* handle,
                                                    int status) {
  WrapType* wrap_data = static_cast<WrapType*>(handle->data);
  CHECK_NOT_NULL(wrap_data);
  CHECK_EQ(&wrap_data->handle_, reinterpret_cast<UVType*>(handle));

  // Local<Value> client_handle;

  if (status == 0) {

    // if (!WrapType::Instantiate(env, wrap_data, WrapType::SOCKET))

    // Unwrap the client  object.
    WrapType* wrap = wrap_data;

    uv_stream_t* client = reinterpret_cast<uv_stream_t*>(&wrap->handle_);
    // uv_accept can fail if the new connection has already been closed, in
    // which case an EAGAIN (resource temporarily unavailable) will be
    // returned.
    if (uv_accept(handle, client)) return;

    // Successful accept. Call the onconnection callback in  land.
    // client_handle = client_obj;
  } else {
    // client_handle = Undefined(env->isolate());
  }

  // Local<Value> argv[] = {Integer::New(env->isolate(), status),
  // client_handle}; wrap_data->MakeCallback(env->onconnection_string(),
  // arraysize(argv), argv);
}

template <typename WrapType, typename UVType>
void ConnectionWrap<WrapType, UVType>::AfterConnect(uv_connect_t* req,
                                                    int status) {
  ConnectWrap* wrap_data = static_cast<ConnectWrap*>(req->data);

  CHECK(wrap_data);
  WrapType* wrap = static_cast<WrapType*>(req->handle->data);

  bool readable, writable;

  if (status) {
    readable = writable = false;
  } else {
    readable = uv_is_readable(req->handle) != 0;
    writable = uv_is_writable(req->handle) != 0;
  }

  // Local<Value> argv[5] = {Integer::New(env->isolate(), status),
  // wrap->object(),
  //                         req_wrap->object(),
  //                         Boolean::New(env->isolate(), readable),
  //                         Boolean::New(env->isolate(), writable)};

  // TRACE_EVENT_NESTABLE_ASYNC_END1(TRACING_CATEGORY_NODE2(net, native),
  //                                 "connect", req_wrap.get(), "status",
  //                                 status);

  // req_wrap->MakeCallback(env->oncomplete_string(), arraysize(argv), argv);
}

template ConnectionWrap<PipeWrap, uv_pipe_t>::ConnectionWrap();

template ConnectionWrap<TCPWrap, uv_tcp_t>::ConnectionWrap();

template void ConnectionWrap<PipeWrap, uv_pipe_t>::OnConnection(
    uv_stream_t* handle, int status);

template void ConnectionWrap<TCPWrap, uv_tcp_t>::OnConnection(
    uv_stream_t* handle, int status);

template void ConnectionWrap<PipeWrap, uv_pipe_t>::AfterConnect(
    uv_connect_t* handle, int status);

template void ConnectionWrap<TCPWrap, uv_tcp_t>::AfterConnect(
    uv_connect_t* handle, int status);
