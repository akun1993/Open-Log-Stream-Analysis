#ifndef SRC_CRYPTO_CONTEXT_H_
#define SRC_CRYPTO_CONTEXT_H_

#include "crypto_util.h"
#include "crypto_keys.h"

namespace crypto {
// A maxVersion of 0 means "any", but OpenSSL may support TLS versions that
// Node.js doesn't, so pin the max to what we do support.
constexpr int kMaxSupportedVersion = TLS1_3_VERSION;

void GetRootCertificates();

bool IsExtraRootCertsFileLoaded();

X509_STORE* NewRootCertStore();

BIOPointer LoadBIO(ByteSource& bsrc);

class SecureContext final {
 public:
  using GetSessionCb = SSL_SESSION* (*)(SSL*, const unsigned char*, int, int*);
  using KeylogCb = void (*)(const SSL*, const char*);
  using NewSessionCb = int (*)(SSL*, SSL_SESSION*);
  using SelectSNIContextCb = int (*)(SSL*, int*, void*);

  ~SecureContext();

  static SecureContext* Create();

  const SSLCtxPointer& ctx() const { return ctx_; }

  // Non-const ctx() that allows for non-default initialization of
  // the SecureContext.
  SSLCtxPointer& ctx() { return ctx_; }

  SSLPointer CreateSSL();

  void SetGetSessionCallback(GetSessionCb cb);
  void SetKeylogCallback(KeylogCb cb);
  void SetNewSessionCallback(NewSessionCb cb);
  void SetSelectSNIContextCallback(SelectSNIContextCb cb);

  inline const X509Pointer& issuer() const { return issuer_; }
  inline const X509Pointer& cert() const { return cert_; }

  bool AddCert(BIOPointer&& bio);
  bool SetCRL(const BIOPointer& bio);

  bool UseKey(std::shared_ptr<KeyObjectData> key);

  void SetCACert(const BIOPointer& bio);
  void SetRootCerts();

  // TODO(joyeecheung): track the memory used by OpenSSL types

  static const int kMaxSessionSize = 10 * 1024;

  // See TicketKeyCallback
  static const int kTicketKeyReturnIndex = 0;
  static const int kTicketKeyHMACIndex = 1;
  static const int kTicketKeyAESIndex = 2;
  static const int kTicketKeyNameIndex = 3;
  static const int kTicketKeyIVIndex = 4;

 protected:
  // OpenSSL structures are opaque. This is sizeof(SSL_CTX) for OpenSSL 1.1.1b:
  static const int64_t kExternalSize = 1024;

  void Init(std::string& sslmethod, int min_version, int max_version);
  void SetKey(ByteSource passphrase, ByteSource& bsrc);
#ifndef OPENSSL_NO_ENGINE
  void SetEngineKey(const char* engine_id, const char* key_name);
#endif  // !OPENSSL_NO_ENGINE
  void SetCert(ByteSource& bsrc);
  void AddCACert(ByteSource& bsrc);
  void AddCRL(ByteSource& bsrc);

  void SetCipherSuites(const char* ciphers);
  void SetCiphers(const char* ciphers);
  void SetSigalgs(char* sigalgs);
  void SetECDHCurve(const char* curve);
  void SetDHParam(bool dhauto, ByteSource& bsrc);
  void SetOptions(int64_t val);
  void SetSessionIdContext(const unsigned char* sessionIdContext);
  void SetSessionTimeout(int32_t sessionTimeout);
  void SetMinProto(int version);
  void SetMaxProto(int version);
  long GetMinProto();
  long GetMaxProto();
  void Close();
  void LoadPKCS12(ByteSource& bsrc);
#ifndef OPENSSL_NO_ENGINE
  void SetClientCertEngine(const char* engine_id);
#endif  // !OPENSSL_NO_ENGINE
  std::string GetTicketKeys();
  void SetTicketKeys(const std::string& buf);

  // void EnableTicketKeyCallback();

  template <bool primary>
  std::string GetCertificate();

  static int TicketKeyCallback(SSL* ssl, unsigned char* name, unsigned char* iv,
                               EVP_CIPHER_CTX* ectx, HMAC_CTX* hctx, int enc);

  static int TicketCompatibilityCallback(SSL* ssl, unsigned char* name,
                                         unsigned char* iv,
                                         EVP_CIPHER_CTX* ectx, HMAC_CTX* hctx,
                                         int enc);

  SecureContext();
  void Reset();

 private:
  SSLCtxPointer ctx_;
  X509Pointer cert_;
  X509Pointer issuer_;
#ifndef OPENSSL_NO_ENGINE
  bool client_cert_engine_provided_ = false;
  EnginePointer private_key_engine_;
#endif  // !OPENSSL_NO_ENGINE

  unsigned char ticket_key_name_[16];
  unsigned char ticket_key_aes_[16];
  unsigned char ticket_key_hmac_[16];
};

}  // namespace crypto

#endif  // SRC_CRYPTO_CRYPTO_CONTEXT_H_
