

#ifndef _CLOCK_QUEUE_BASE_H
#define _CLOCK_QUEUE_BASE_H

#include <time.h>
#include <set>
#include <vector>
#include <functional>
#include <uv.h>
#include "time_tick.h"
#include "timer_id.h"
#include "timer.h"

class LoopWrap;


class ClockQueueBase {
public:
    explicit ClockQueueBase(LoopWrap* loop,clockid_t clockid);
    ~ClockQueueBase();

    // /
    // / Schedules the callback to be run at given time,
    // / repeats if @c interval > 0.0.
    // /
    // / Must be thread safe. Usually be called from other threads.
    TimerId addTimer(TimerCallback cb, Timetick when, double interval);

    void cancel(TimerId timerId);

private:
    friend void poll_cb(uv_poll_t* watcher, int status, int events);
    // FIXME: use unique_ptr<Timer> instead of raw pointers.
    // This requires heterogeneous comparison lookup (N3465) from C++14
    // so that we can find an T* in a set<unique_ptr<T>>.
    typedef std::pair<Timetick, Timer*> Entry;
    typedef std::set<Entry> TimerList;
    typedef std::pair<Timer*, int64_t> ActiveTimer;
    typedef std::set<ActiveTimer> ActiveTimerSet;

    void addTimerInLoop(Timer* timer);
    void cancelInLoop(TimerId timerId);
    // called when timerfd alarms
    void handleRead(uv_poll_t* poll, int status, int events);
    // move out all expired timers
    std::vector<Entry> getExpired(Timetick now);
    void reset(const std::vector<Entry>& expired, Timetick now);

    bool insert(Timer* timer);

    LoopWrap* loop_;
    uv_poll_t poll_handle_;
    const int timerfd_;

    // Timer list sorted by expiration
    TimerList timers_;

    // for cancel()
    ActiveTimerSet activeTimers_;
    bool callingExpiredTimers_; /* atomic */
    ActiveTimerSet cancelingTimers_;
};

#endif  // MUDUO_NET_TIMERQUEUE_H
