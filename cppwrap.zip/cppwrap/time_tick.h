

#ifndef EVENT_Timetick_H
#define EVENT_Timetick_H

#include <stdint.h>
#include <string.h>  // memset
#include <string>

///
/// Time tick , in microseconds resolution.
///
/// This class is immutable.
/// It's recommended to pass it by value, since it's passed in register on x64.
///

class Timetick {
public:
    ///
    /// Constucts an invalid Timetick.
    ///
    Timetick() : microSecondsTicks_(0) {
    }

    ///
    /// Constucts a Timetick at specific time
    ///
    /// @param microSecondsTicks
    explicit Timetick(int64_t microSecondsTicksArg) : microSecondsTicks_(microSecondsTicksArg) {
    }

    void swap(Timetick& that) {
        std::swap(microSecondsTicks_, that.microSecondsTicks_);
    }

    // default copy/assignment/dtor are Okay

    std::string toString() const;

    bool valid() const {
        return microSecondsTicks_ > 0;
    }

    // for internal usage.
    int64_t microSecondsTicks() const {
        return microSecondsTicks_;
    }

    ///
    /// Get time of now.
    ///
    static Timetick now();
    static Timetick invalid() {
        return Timetick();
    }

    static Timetick fromUnixTime(time_t t) {
        return fromUnixTime(t, 0);
    }

    static Timetick fromUnixTime(time_t t, int microseconds) {
        return Timetick(static_cast<int64_t>(t) * kMicroSecondsPerSecond + microseconds);
    }

    static const int kMicroSecondsPerSecond = 1000 * 1000;

private:
    int64_t microSecondsTicks_;
};

inline bool operator<(Timetick lhs, Timetick rhs) {
    return lhs.microSecondsTicks() < rhs.microSecondsTicks();
}

inline bool operator<=(Timetick lhs, Timetick rhs) {
    return lhs.microSecondsTicks() <= rhs.microSecondsTicks();
}

inline bool operator>(Timetick lhs, Timetick rhs) {
    return !(lhs <= rhs);
}

inline bool operator>=(Timetick lhs, Timetick rhs) {
    return !(lhs < rhs);
}

inline bool operator==(Timetick lhs, Timetick rhs) {
    return lhs.microSecondsTicks() == rhs.microSecondsTicks();
}

inline bool operator!=(Timetick lhs, Timetick rhs) {
    return !(lhs == rhs);
}

///
/// Gets time difference of two Timeticks, result in seconds.
///
/// @param high, low
/// @return (high-low) in seconds
/// @c double has 52-bit precision, enough for one-microsecond
/// resolution for next 100 years.
inline double timeDifference(Timetick high, Timetick low) {
    int64_t diff = high.microSecondsTicks() - low.microSecondsTicks();
    return static_cast<double>(diff) / Timetick::kMicroSecondsPerSecond;
}

///
/// Add @c seconds to given Timetick.
///
/// @return Timetick+seconds as Timetick
///
inline Timetick addTime(Timetick timetick, double seconds) {
    int64_t delta = static_cast<int64_t>(seconds * Timetick::kMicroSecondsPerSecond);
    return Timetick(timetick.microSecondsTicks() + delta);
}

#endif  //_BASE_Timetick_H
